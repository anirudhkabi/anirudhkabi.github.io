opkg install zlib_1.2.7-1_ar71xx.ipk
opkg install libopenssl_1.0.1h-1_ar71xx.ipk
opkg install libcurl_7.29.0-1_ar71xx.ipk
opkg install curl_7.29.0-1_ar71xx.ipk
