./iperf
./snmp
./ui
./curl.sh
