opkg install libipq_1.4.10-4_ar71xx.ipk
opkg install fractel_0.2.1-1_ar71xx.ipk 
