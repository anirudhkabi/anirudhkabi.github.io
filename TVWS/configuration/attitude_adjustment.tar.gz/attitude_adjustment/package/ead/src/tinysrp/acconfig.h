#undef SHA1HANDSOFF

#undef POSIX_TERMIOS

#undef POSIX_SIGTYPE

#undef VERSION

#undef volatile
