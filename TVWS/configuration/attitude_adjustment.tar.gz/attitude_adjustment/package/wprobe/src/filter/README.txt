To compile pfc you need at least libpcap version 1.0, as it requires proper radiotap header support
