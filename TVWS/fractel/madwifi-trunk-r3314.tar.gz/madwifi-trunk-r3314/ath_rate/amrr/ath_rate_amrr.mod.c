#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xc0196af1, "struct_module" },
	{ 0x54a366c0, "proc_dointvec_minmax" },
	{ 0xb80330df, "kmalloc_caches" },
	{ 0x83e84bbe, "__mod_timer" },
	{ 0x2daa90e5, "register_sysctl_table" },
	{ 0x98b1f5e8, "del_timer" },
	{ 0x7d11c268, "jiffies" },
	{ 0xfedc13d3, "ieee80211_rate_register" },
	{ 0xdd132261, "printk" },
	{ 0xd8441d4c, "ieee80211_rate_unregister" },
	{ 0xa1c9f3d, "mod_timer" },
	{ 0x71ff5c99, "ieee80211_iterate_nodes" },
	{ 0x6f6be5c4, "module_put" },
	{ 0x8710888f, "kmem_cache_alloc" },
	{ 0x63e71329, "unregister_sysctl_table" },
	{ 0x2ad47c12, "init_timer" },
	{ 0x37a0cba, "kfree" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=wlan";


MODULE_INFO(srcversion, "B3CABA78BB5D6B3FBE0498F");
