#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xc0196af1, "struct_module" },
	{ 0xb80330df, "kmalloc_caches" },
	{ 0x83e84bbe, "__mod_timer" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0xa5423cc4, "param_get_int" },
	{ 0x98b1f5e8, "del_timer" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0xd091bf85, "ieee80211_proc_vcreate" },
	{ 0x2fd1d81c, "vfree" },
	{ 0xcb32da10, "param_set_int" },
	{ 0xeaa456ed, "_spin_lock_irqsave" },
	{ 0x1d26aa98, "sprintf" },
	{ 0x7d11c268, "jiffies" },
	{ 0xfedc13d3, "ieee80211_rate_register" },
	{ 0xde0bdcff, "memset" },
	{ 0xdd132261, "printk" },
	{ 0xd8441d4c, "ieee80211_rate_unregister" },
	{ 0x27147e64, "_spin_unlock_irqrestore" },
	{ 0x71ff5c99, "ieee80211_iterate_nodes" },
	{ 0x6f6be5c4, "module_put" },
	{ 0x8710888f, "kmem_cache_alloc" },
	{ 0x2ad47c12, "init_timer" },
	{ 0x6e8da507, "ath_hal_computetxtime" },
	{ 0x37a0cba, "kfree" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=wlan,ath_hal";


MODULE_INFO(srcversion, "08AF8ECB772FAFE71B9413F");
