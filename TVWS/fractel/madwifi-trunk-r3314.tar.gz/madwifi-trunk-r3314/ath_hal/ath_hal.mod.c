#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xc0196af1, "struct_module" },
	{ 0x5a34a45c, "__kmalloc" },
	{ 0x2daa90e5, "register_sysctl_table" },
	{ 0xcda31108, "proc_dointvec" },
	{ 0x7d11c268, "jiffies" },
	{ 0xde0bdcff, "memset" },
	{ 0xdd132261, "printk" },
	{ 0x6f6be5c4, "module_put" },
	{ 0x63e71329, "unregister_sysctl_table" },
	{ 0xe57f111, "vsnprintf" },
	{ 0x37a0cba, "kfree" },
	{ 0x6067a146, "memcpy" },
	{ 0xaf25400d, "snprintf" },
	{ 0x9e7d6bd0, "__udelay" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "E6EBD38062C1615A90D0178");
