#ifdef DO_MULTI
int a80211debug_init(int argc, char *argv[]);
int a80211stats_init(int argc, char *argv[]);
int athchans_init(int argc, char *argv[]);
int athctrl_init(int argc, char *argv[]);
int athdebug_init(int argc, char *argv[]);
int athkey_init(int argc, char *argv[]);
int athstats_init(int argc, char *argv[]);
int wlanconfig_init(int argc, char *argv[]);
int athinfo_init(int argc, char *argv[]);

#define CMD(name) name##_init
#else
#define CMD(name) main
#endif
