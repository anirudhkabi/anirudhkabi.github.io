#ifndef _UTIL_H
#define _UTIL_H 
#define MAX_LOG_SIZE 800
#define US2TU_8(x) ((x)>>7) 
#define US2TU(x) ((x)>>10)
#define SOFTMS(x) jiffies + ((HZ * (x)) / 1000)
#define TIME_TO_SEND 100000
#define SCHEDULE_START_TIME 1
#define ONE_MILLION 1000000
#define SLOT_DURATION 1000000

#define PLCP_HEADER 21
#define INTER_PACKET_GAP 25

#define TXQ_FLAG_BACKOFF_DISABLE 0x0010

char log_buffer[MAX_LOG_SIZE][255];
char routing_log_buffer[MAX_LOG_SIZE][255];
int log_index=0;
int cross_over=0;
int condition_log=0;
unsigned long log_no_wrap_index=0;
//vl change start
int routing_log_index=0;
unsigned int routing_log_nowrap_index=0;
//vl change end

long custom_atol(const char * str)
{
	long i=0;
	long j=0;
	int nonum=0;
	while(*str!='\0')
	{
		switch(*str)
		{
		case '1':i=1;
			break;
		case '2':i=2;
			break;
		case '3':i=3;
			break;
		case '4':i=4;
			break;
		case '5':i=5;
			break;
		case '6':i=6;
			break;
		case '7':i=7;
			break;
		case '8':i=8;
			break;
		case '9':i=9;
			break;
		case '0':i=0;
			break;
		default: nonum=1;
			break;			
		}
	if (nonum==1)
		break;
	j=j*10+i;
	str++;
	
	}
	return j;
}	

char* custom_strtok (char * str,char delim)
{
	char *str_original;
	static char * next_str;
	
	if (str==NULL)
	{
		str=next_str;
		str_original=str;
		if (*next_str=='\0')
		{
			return NULL;
		}
	}
	else
	{
		str_original=str;
	}
	while (*str!='\0' && *str!=delim)
	{
	str++;
	}
	if(*str!='\0')
	{
		*str='\0';
		next_str=++str;
	}
	else
	{
		next_str=str;
	}
	return str_original;
}

unsigned long ip_string_to_long(char *in_str)
{
	char str[16];
	char *str1;
	unsigned long l=0;
	
	strcpy(str, in_str);
	str1=custom_strtok(str,'.');
	while (1)
	{	
		l+=custom_atol(str1);
				
		str1=custom_strtok(NULL,'.');
		if (str1==NULL) 
		{
			break;		
		}
		else
		{
			l=l<<8;
		}
	}
	return l;
}

void log(int severity, char *func, int event_id, unsigned long long timestamp, char *desc) {
	char *buff;
	if (condition_log==6222)//only if condition then it will be logged.
	{
		buff = log_buffer[log_index];
		
		sprintf(buff, "[%lu] %d,%d,%s,%d,%llu,%s", log_no_wrap_index, severity, 0, func, event_id, timestamp, desc);
		log_no_wrap_index++;
		log_index++;
		if (log_index >= MAX_LOG_SIZE)
		{
			cross_over=1;
			log_index = (log_index) % MAX_LOG_SIZE;
		}
	}
}

//vl change start
void routing_log(uint32_t ip1, uint32_t ip2) {
	char *buff;
	
	buff = routing_log_buffer[routing_log_index];	
	sprintf(buff, "%u %u %u", routing_log_nowrap_index, ip1, ip2);
	log(1, (char *)__func__, 99999, routing_log_index, buff);
	routing_log_index++;
	routing_log_nowrap_index++;
	if (routing_log_index >= MAX_LOG_SIZE)
	{
		routing_log_index = (routing_log_index) % MAX_LOG_SIZE;
	}
}
//vl change end

void FRACTEL_log_printer(unsigned long sc_ptr)
{
	int i;
	char *buff;

	if (cross_over==1)
	{
		for (i=log_index;i<MAX_LOG_SIZE;i++)
		{
			buff = log_buffer[i];
			//printf("%s\n", buff);
		}
		for(i=0;i<log_index;i++)
		{
			buff = log_buffer[i];
			//printf("%s\n", buff);
		}
	}
	else
	{
		for(i=0;i<log_index;i++)
		{
			buff = log_buffer[i];
			//printf("%s\n", buff);
		}
	}
}
#endif
