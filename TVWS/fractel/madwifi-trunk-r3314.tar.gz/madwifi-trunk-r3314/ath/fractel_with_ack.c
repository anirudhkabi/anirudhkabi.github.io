#ifndef _FRACTEL_H
#define _FRACTEL_H 

//#define INTERVAL 5
#define TDMA_SLOT_INTERVAL(x) (jiffies + ((HZ * (x)) / 1000))
#define TDMA_BEACON_INTERVAL (jiffies + ((HZ * (4000)) / 1000))
#define FRACTEL_START_TRIGGER (jiffies + ((HZ * (8000)) / 1000))
#define FRACTEL_LOG_INTERVAL (jiffies + ((HZ * (60000)) / 1000))

#define BROADCAST_MAC 0xffffffffffffLL
#define BROADCAST_IP 0xffffffffL
#define CRC_LENGTH 4
#define TRANSMIT_TIME_COMPENSATION 52
#define ATH_DEBUG_TDMA 0
#define FRACTEL_DEBUG 0

//macro for debugging
#define	FRACTEL_PRINTF(_fmt, ...) do {				\
	if (FRACTEL_DEBUG) 					\
		printk(KERN_DEBUG "%s: " _fmt, \
			__func__, ## __VA_ARGS__); \
} while (0)


extern int INTERVAL;
extern int NO_OF_SLOTS;
extern int NO_OF_CONTROL_SLOTS;
extern int NO_OF_CONTENTION_SLOTS;
extern int NO_OF_DATA_SLOTS;
extern int MAX_NO_OF_RSSI_VALUES;
extern int RSSI_SENSE_TIMEOUT;
extern int fractel_operation_started;
extern int NODE_ID;
extern int ERROR_RATE;
extern char* SELF_NODE_ID;
extern char* ROOT_IP;
extern int fractel_data_rate;

int TDMA_STATUS=1;

// struct TDMA_node_list {
// 	struct TDMA_node *head;
// 	u_int64_t rx_node;
// 	u_int16_t seq_num;
// };

struct TDMA_node {
	struct sk_buff *skb;
	struct net_device *dev;
	struct TDMA_node *next;
	//added -- vs change start
	struct TDMA_node *prev; 
	u_int16_t seq_num;
	u_int8_t retx_count; //added for per pkt ack 
	u_int8_t pkt_successful;
	u_int64_t node_count; //added for debugging -- vs
	// -- vs change end
};

/* struct TDMA_node is a list of pkts for a given rx node; TDMA_node_list is list of TDMA_nodes for all the receivers */
struct TDMA_node_list {
	struct TDMA_node *head;
	struct TDMA_node *tail;
	struct TDMA_node *curr_node_pointer;
	u_int64_t rx_node;
	u_int16_t seq_num;
	u_int32_t buffer_size;
	struct TDMA_node_list *next;
};
/**
A Schedule is sent in a control slot with the schedule header followed by possibly a routing 
tree and possibly # of scheduling elements. Schedule header contains synchronization information.

The more_fragments bit is set if the entire schedule spans over multiple packets. The last fragment
will have this bit reset.
*/
struct fractel_schedule_header {
uint8_t fractel_frame;
uint8_t packet_type;
uint16_t reserved; //To supress NAV calculation (duration field)
uint32_t node_id;
int64_t offset;
uint64_t valid_from; 
uint64_t timestamp;
uint16_t no_of_scheduling_elements;
uint16_t no_of_data_slots;
uint16_t max_control_slots;
uint16_t max_contention_slots; //changed for node join
uint16_t slot_interval; //slot interval need not be configurable, nodes other than root node can take determine slot interval during node join
uint8_t routing_tree_changed:1;
uint8_t more_fragments:1;
uint8_t schedule_repeat:1;
uint16_t routing_tree_length;
uint64_t valid_upto;
uint64_t slot_start;
uint16_t this_slot_no;
uint32_t sequence_number;
} __packed;

/**
Each scheduling element points to block of slots which are to be used by the tx node 
to transfer data belonging to the given flow_id to the rx node.
*/
struct fractel_schedule_element {
uint8_t channel;
uint16_t flow_id;
uint32_t rx;
uint32_t tx;
uint32_t end_source;
uint32_t end_destination;
uint16_t data_slot_no;
uint8_t no_of_assigned_slots;
};

/**
Every schedule will have a (possibly zero)number of routing_tree_elements; 
each indicating a parent-child relationship. The whole set creates complete 
routing tree. 
*/
struct fractel_routing_tree_element {
uint32_t parent_node;
uint32_t child_node;
};

/**
A data header is attached to each data packets received from network layer.
Information inside the data packet will help making routing decision  
*/
struct fractel_data_header {
uint8_t fractel_frame;
uint8_t packet_type;
uint16_t reserved;//To supress NAV calculation (duration field)
uint16_t flow_id;  //reserved as of now 
uint32_t node_id;  //added by vl for node join
uint64_t rx;
uint64_t tx;
//uint32_t end_source;
//uint32_t end_destination;
uint64_t slot_end_time;   //remove this field after testing 
uint16_t reserved2;
uint16_t seq_no;
uint8_t to_drop;
uint8_t retx_count;
} __packed;

//Vishal-Lokendra change start
/**
Structure to hold the rssi values and the nodes from which these are received, before node join is done 
*/
struct rssi_vals {
	uint8_t num_parents;
	uint32_t parent_ids[10];
	int8_t rssi_values[10];	
};

 

/**
Header for node join requests
*/ 
struct fractel_node_join_header {
uint8_t fractel_frame;
uint8_t packet_type;
uint16_t reserved;//To supress NAV calculation (duration field)
struct rssi_vals rssi_info;
uint32_t parent_id; //id of the node to whom the packet will be forwarded
uint32_t self_ip; //ip of self, to be used for node join 
} __packed;

// -- vs change start
//structure to hold packets for reordering; pkts have to be queued based on flow but as of yet per flow queue mangement has not been implemented
// struct pkt_queue{
// 	struct sk_buff *skb;
// 	struct ath_buf *bf;
// 	u_int16_t seq_num;
// 	u_int64_t arrival_time; // when (curr_time - arrival_time) becomes greater than timeout pkt is passed up the protocol stack 
// 	struct pkt_queue *next;
// 	struct pkt_queue *prev;
// };

//using static allocation
struct pkt_queue{
	struct sk_buff *skb;
	struct ath_buf *bf;
	u_int16_t seq_num;
	u_int64_t arrival_time; // when (curr_time - arrival_time) becomes greater than timeout pkt is passed up the protocol stack 
	u_int64_t timeout;
};

//this structure holds the pkt queue for each flow
// struct reorder_queue{
// 	struct pkt_queue *head;
// 	struct pkt_queue *tail;
// 	struct pkt_queue *wrap_around_pointer; //this variable points to pkt with sequence num zero and is used when sequence number wraps around
// 	u_int16_t node_id;
// 	u_int16_t flowid;
// 	u_int16_t expected_next_seq_num;
// 	u_int64_t inactivity_time; //this variable is used to delete the queue if inactivity_time is more than the timeout value
// 	struct reorder_queue *next;
// };
//using static allocation instead of dynamic allocation
struct reorder_queue{
	struct pkt_queue pkts[5000];
	u_int16_t node_id;
	u_int16_t flowid;
	u_int16_t num_pkts;
	u_int16_t expected_next_seq_num;
	u_int32_t curr_array_index;
	u_int64_t inactivity_time; //this variable is used to delete the queue if inactivity_time is more than the timeout value
};
// -- vs change end


//Vishal-Lokendra change end

#define DATA_HDR_LEN sizeof(struct fractel_data_header)

struct mac_to_ip{
	uint64_t mac;
	uint32_t ip;
	char *node_name;
};

struct routing_map{
	uint32_t node_ip;
	uint32_t end_destination_ip;
	uint32_t next_hop_ip;
};

//A -- New set ubiquity + microtic
// 00-15-6D-55-4F-67  -- 92028620647
// 00-0C-42-18-FA-A3  -- 52648540835
// 00-0C-42-1F-17-23  -- 52648941347
// 00-0C-42-1F-16-94  -- 52648941204
//  00-15-6D-55-4F-68  -- 92028620648



// 00-15-6D-55-4F-64    --- 92028620644
// 00-15-6D-55-4F-5B

//00-15-6d-55-4f-5c  -- 92028620636
#define ROUTING_ENTRIES 4
struct mac_to_ip mac_ip_map[]={	

//for som node			{92029594703LL, 3232235521LL, "root"},
				{92029592857LL, 3232235521LL, "root"}, //main building node
				{92029592842LL, 3232235522LL, "client-1"},
//				{92029592857LL, 3232235522LL, "client-1"},
				{92029592844LL, 3232235523LL, "client-2"},
//			      	{92028620677LL, 3232235524LL, "client-3"},
//				{92028620644LL, 3232235525LL, "client-4"},
				{BROADCAST_MAC, BROADCAST_IP, "broadcast"}



//				{92028620646LL, 3232235521LL, "root"},
				//{92028620635LL, 3232235522LL, "client-1"},
//				{92028620635LL, 3232235523LL, "client-2"},
//			      	{92028620677LL, 3232235524LL, "client-3"},
//				{92028620644LL, 3232235525LL, "client-4"},
				//{BROADCAST_MAC, BROADCAST_IP, "broadcast"}
				};
#define MULTIHOP_ROUTING_MAP_ENTRY 6
//				{Source,FinalDestination,NextHop}
struct routing_map routing_entry[]={	
				{3232235521LL, 3232235522LL, 3232235522LL},
				{3232235521LL, 3232235523LL, 3232235522LL},
				{3232235522LL, 3232235523LL, 3232235523LL},
//				{3232235522LL, 3232235525LL, 3232235523LL},
//				{3232235523LL, 3232235525LL, 3232235525LL},
//				{3232235525LL, 3232235521LL, 3232235523LL},
//				{3232235523LL, 3232235521LL, 3232235522LL},
				{3232235523LL, 3232235521LL, 3232235522LL},
				{3232235523LL, 3232235522LL, 3232235522LL},
				{3232235522LL, 3232235521LL, 3232235521LL},
				};

#define RETRY_FLAG 0x08
//In the following enumeration, values must be used carefully.
//The Retry bit 0x08 must always be set
//Not all numeric values are allowed. This is because the hardware may modify
//certain bytes (22,23 or 30,31) depending on the value of this byte.
//RETRY_FLAG | 3 combination will cause the bytes 26,27 to be copied to 30,31
enum {
	FRACTEL_SCHEDULE = RETRY_FLAG,
	FRACTEL_NODE_JOIN = RETRY_FLAG | 1,
	FRACTEL_BW_REQUEST = RETRY_FLAG | 2,
	FRACTEL_DATA = RETRY_FLAG | 4
};

enum {
	FRACTEL_IDLE_STATE,
	FRACTEL_PREPARE_SCHEDULE,
	FRACTEL_SEND_SCHEDULE,
	FRACTEL_EVENT,
	FRACTEL_DUMMY_STATE,
	FRACTEL_EVENT_DONE
};

enum {
	FRACTEL_NODE_JOIN_IDLE,
	FRACTEL_NODE_JOIN_LISTENING,
	FRACTEL_SENDING_NODE_JOIN,
	FRACTEL_NODE_JOIN_REQUESTED,
	FRACTEL_NODE_JOIN_DONE	
};

enum {
	FRACTEL_LOG_WAITING_FOR_SCHEDULE,
	FRACTEL_LOG_SCHEDULE_PREPARE,
	FRACTEL_LOG_SCHEDULE_SEND,
	FRACTEL_LOG_SCHEDULE_RECEIVED,
	FRACTEL_LOG_TX_EVENT,
	FRACTEL_LOG_RX_EVENT,
	FRACTEL_LOG_EVENT_INFO,
	FRACTEL_LOG_SLOT_START,
	FRACTEL_LOG_SLOT_END,
	FRCATEL_LOG_DATA_RECEIVED,
	FRCATEL_LOG_SCHEDULE_SEQUENCE_NUMBER
};

char* fractel_log[12] = {
	"FRACTEL_LOG_WAITING_FOR_SCHEDULE",
	"FRACTEL_LOG_SCHEDULE_PREPARE",
	"FRACTEL_LOG_SCHEDULE_SEND",
	"FRACTEL_LOG_SCHEDULE_RECEIVED",
	"FRACTEL_LOG_TX_EVENT",
	"FRACTEL_LOG_RX_EVENT",
	"FRACTEL_LOG_SLOT_START",
	"FRACTEL_LOG_SLOT_END"
	};

static struct TDMA_node *TDMA_head=NULL, *TDMA_tail=NULL, *TDMA_head_node_join=NULL, *TDMA_tail_node_join=NULL;
static struct timer_list fractel_event_timer;
static struct timer_list fractel_bootstrap_timer;

//static void TDMA_beacon_send(unsigned long sc_ptr);
static int fractel_TDMA_add_to_buffer(struct sk_buff *skb, struct net_device *dev);
static int TDMA_remove_from_buffer(struct sk_buff **skb, struct net_device **dev);
static void TDMA_send_triggered(unsigned long sc_ptr, unsigned long long last_tx_time);
static int TDMA_get_buffer_size(void);
static int TDMA_get_packet_params(int *pcklen);
void fractel_prepare_schedule(struct ieee80211_node * ni, struct ath_hal *ah, unsigned long long);
void fractel_create_schedule(struct sk_buff * skb);
void fractel_do_node_join(struct ieee80211_node * ni, struct ath_hal *ah);
//void fractel_send_node_join_request();
uint32_t get_gw_for_destination(uint32_t destination); //added by vl
void fractel_add_routing_entries(); //added by vl to modify the routing table whenever new node joins the topology
uint8_t is_routing_tree_changed(struct fractel_routing_tree_element* r_tree);
// -- vs change start
void addToReorderQueue(struct sk_buff *skb, struct ath_buf *bf, u_int16_t node_id, u_int16_t flowid, u_int16_t seq_num, u_int8_t retx_count, u_int64_t arrival_time,struct ath_softc *sc); //function that inserts out of order packets in the queue
void clearReorderQueue(struct ath_softc *); //function that removes the packet from reorder queue and sends up the protocol stack
void clearReorderQueue_scheduled(TQUEUE_ARG data);
void shiftElementUpTheArray(u_int8_t queue);
void clearStaleState(u_int16_t node_id);
u_int8_t is_broadcast_pkt(struct sk_buff *skb);
struct TDMA_node_list* fractel_get_TDMA_list(struct sk_buff *skb);
// -- vs change end
static long TDMA_buffer_size=0, TDMA_buffer_node_join_size=0;

#endif
