/*-
 * Copyright (c) 2003-2005 Sam Leffler, Errno Consulting
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: ieee80211_linux.c 3268 2008-01-26 20:48:11Z mtaylor $
 */
#ifndef EXPORT_SYMTAB
#define	EXPORT_SYMTAB
#endif

/*
 * IEEE 802.11 support (Linux-specific code)
 */
#ifndef AUTOCONF_INCLUDED
#include <linux/config.h>
#endif
#include <linux/version.h>
#include <linux/module.h>
#include <linux/kmod.h>
#include <linux/init.h>
#include <linux/skbuff.h>
#include <linux/sysctl.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/if_vlan.h>
#include <linux/vmalloc.h>
#include <linux/proc_fs.h>

#include <net/iw_handler.h>
#include <linux/wireless.h>
#include <linux/if_arp.h>		/* XXX for ARPHRD_* */

#include <asm/uaccess.h>

#include "if_media.h"
#include "if_ethersubr.h"

#include <net80211/ieee80211_var.h>
#include <net80211/ieee80211_monitor.h>
#include <asm/div64.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
#include <linux/device.h>

/* madwifi_name_type - device name type:
 * values:	0:	automatically assigned
 * 		1:	administratively assigned
 * 		else:	reserved			*/

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,21)
static ssize_t show_madwifi_name_type(struct device *dev,
		struct device_attribute *attr, char *buf)
#else
static ssize_t show_madwifi_name_type(struct class_device *cdev,
		char *buf)
#endif
{
	ssize_t len = 0;

	len = snprintf(buf, PAGE_SIZE, "1");

	return len;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,21)
static DEVICE_ATTR(madwifi_name_type, S_IRUGO, show_madwifi_name_type, NULL);
#else
static CLASS_DEVICE_ATTR(madwifi_name_type, S_IRUGO, show_madwifi_name_type, NULL);
#endif

static struct attribute *ieee80211_sysfs_attrs[] = {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,21)
	&dev_attr_madwifi_name_type.attr,
#else
	&class_device_attr_madwifi_name_type.attr,
#endif
	NULL
};

static struct attribute_group ieee80211_attr_grp = {
	.name	= NULL,	/* No seperate (sub-)directory */
	.attrs	= ieee80211_sysfs_attrs
};
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17) */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,24)
#define proc_net init_net.proc_net
#endif

//Ashutosh-Nirav change start
#define MAX_LOG_SIZE 800

int NODE_ID = 0;
char *SELF_NODE_ID="192.168.0.1";
char *ROOT_IP="192.168.0.10"; //vl change

int INTERVAL=2;
int NO_OF_SLOTS=100;
int NO_OF_CONTROL_SLOTS=3;
int NO_OF_CONTENTION_SLOTS=5;
int NO_OF_DATA_SLOTS=92;
int MAX_NO_OF_RSSI_VALUES=3;
int RSSI_SENSE_TIMEOUT=10000;
int ERROR_RATE=0;
int fractel_operation_started=0;
int fractel_data_rate=11;
int custom_topology=0;
int frame_length = 0;
//these are data slot numbers for a given node in the frame
int slot1 = -1;
int slot2 = -1;
int slot3 = -1;
int slot4 = -1;
int slot5 = -1;

uint32_t parent=0;

EXPORT_SYMBOL(INTERVAL);
EXPORT_SYMBOL(NO_OF_SLOTS);
EXPORT_SYMBOL(NO_OF_CONTENTION_SLOTS);
EXPORT_SYMBOL(NO_OF_CONTROL_SLOTS);
EXPORT_SYMBOL(NO_OF_DATA_SLOTS);
EXPORT_SYMBOL(MAX_NO_OF_RSSI_VALUES);
EXPORT_SYMBOL(RSSI_SENSE_TIMEOUT);
EXPORT_SYMBOL(fractel_operation_started);
EXPORT_SYMBOL(NODE_ID);
EXPORT_SYMBOL(SELF_NODE_ID);

//vs change start
EXPORT_SYMBOL(ROOT_IP); //root ip, vl change
EXPORT_SYMBOL(ERROR_RATE); //vl change
EXPORT_SYMBOL(fractel_data_rate); //vl change
EXPORT_SYMBOL(custom_topology); //vs change
EXPORT_SYMBOL(parent); //vs change
EXPORT_SYMBOL(frame_length);
EXPORT_SYMBOL(slot1);
EXPORT_SYMBOL(slot2);
EXPORT_SYMBOL(slot3);
EXPORT_SYMBOL(slot4);
EXPORT_SYMBOL(slot5);
//vs change end

char* fractel_config_variables[19] = {
	"node_id",
	"self_node_ip",
	"no_of_control_slots",
	"no_of_contention_slots",
	"no_data_slots",
	"max_no_of_rssi_values",
	"rssi_sense_timeout",
	"interval",
	"root_ip",
	"error_rate",
	"fractel_data_rate",
	"custom_topology",
	"parent",
	"frame_length",
	"slot1",
	"slot2",
	"slot3",
	"slot4",
	"slot5"
	};

//Ashutosh-Nirav Addition Ends

/*
 * Print a console message with the device name prepended.
 */
void
if_printf(struct net_device *dev, const char *fmt, ...)
{
	va_list ap;
	char buf[512];		/* XXX */

	va_start(ap, fmt);
	vsnprintf(buf, sizeof(buf), fmt, ap);
	va_end(ap);

	printk("%s: %s", dev->name, buf);
}

/*
 * Allocate and setup a management frame of the specified
 * size.  We return the sk_buff and a pointer to the start
 * of the contiguous data area that's been reserved based
 * on the packet length.  The data area is forced to 32-bit
 * alignment and the buffer length to a multiple of 4 bytes.
 * This is done mainly so beacon frames (that require this)
 * can use this interface too.
 */
struct sk_buff *
#ifdef IEEE80211_DEBUG_REFCNT
ieee80211_getmgtframe_debug(u_int8_t **frm, u_int pktlen, 
		const char* func, int line)
#else
ieee80211_getmgtframe(u_int8_t **frm, u_int pktlen)
#endif
{
	const u_int align = sizeof(u_int32_t);
	struct sk_buff *skb;
	u_int len;

	len = roundup(sizeof(struct ieee80211_frame_addr4) + pktlen + 700, 4);
#ifdef IEEE80211_DEBUG_REFCNT
	skb = ieee80211_dev_alloc_skb_debug(len + align - 1, func, line);
#else
	skb = ieee80211_dev_alloc_skb(len + align - 1);
#endif
	if (skb != NULL) {
		u_int off = ((unsigned long) skb->data) % align;
		if (off != 0)
			skb_reserve(skb, align - off);

		SKB_CB(skb)->auth_pkt = 0;
		SKB_CB(skb)->ni = NULL;
		SKB_CB(skb)->flags = 0;
		SKB_CB(skb)->next = NULL;

		skb_reserve(skb, sizeof(struct ieee80211_frame_addr4)+700);
		*frm = skb_put(skb, pktlen);
	}
	return skb;
}
#ifdef IEEE80211_DEBUG_REFCNT
EXPORT_SYMBOL(ieee80211_getmgtframe_debug);
#else
EXPORT_SYMBOL(ieee80211_getmgtframe);
#endif 

#if IEEE80211_VLAN_TAG_USED
/*
 * VLAN support.
 */

/*
 * Register a vlan group.
 */
static void
ieee80211_vlan_register(struct net_device *dev, struct vlan_group *grp)
{
	struct ieee80211vap *vap = netdev_priv(dev);

	vap->iv_vlgrp = grp;
}

/*
 * Add an rx vlan identifier
 */
static void
ieee80211_vlan_add_vid(struct net_device *dev, unsigned short vid)
{
	struct ieee80211vap *vap = netdev_priv(dev);

	if (vap->iv_vlgrp != NULL)
		vap->iv_bss->ni_vlan = vid;
}

/*
 * Kill (i.e. delete) a vlan identifier.
 */
static void
ieee80211_vlan_kill_vid(struct net_device *dev, unsigned short vid)
{
	struct ieee80211vap *vap = netdev_priv(dev);

	if (vap->iv_vlgrp != NULL)
		vlan_group_set_device(vap->iv_vlgrp, vid, NULL);
}
#endif /* IEEE80211_VLAN_TAG_USED */

void
ieee80211_vlan_vattach(struct ieee80211vap *vap)
{
#if IEEE80211_VLAN_TAG_USED
	struct net_device *dev = vap->iv_dev;

	dev->features |= NETIF_F_HW_VLAN_TX | NETIF_F_HW_VLAN_RX |
			 NETIF_F_HW_VLAN_FILTER;
	dev->vlan_rx_register = ieee80211_vlan_register;
	dev->vlan_rx_add_vid = ieee80211_vlan_add_vid;
	dev->vlan_rx_kill_vid = ieee80211_vlan_kill_vid;
#endif /* IEEE80211_VLAN_TAG_USED */
}

void
ieee80211_vlan_vdetach(struct ieee80211vap *vap)
{
}

void
ieee80211_update_link_status(struct ieee80211vap *vap, int nstate, int ostate)
{
	struct net_device *dev = vap->iv_dev;
	union iwreq_data wreq;
	int active;

	if (vap->iv_opmode != IEEE80211_M_STA)
		return;

	if (ostate == nstate)
		return;

	if (nstate == IEEE80211_S_RUN)
		active = 1;
	else if ((ostate >= IEEE80211_S_AUTH) && (nstate < ostate))
		active = 0;
	else
		return;

	if (active && !vap->iv_bss)
		return;

	memset(&wreq, 0, sizeof(wreq));
	wreq.ap_addr.sa_family = ARPHRD_ETHER;

	if (active) {
		//netif_carrier_on(vap->iv_dev);
		IEEE80211_ADDR_COPY(wreq.addr.sa_data, vap->iv_bssid);
	} else {
		//netif_carrier_off(vap->iv_dev);
		memset(wreq.ap_addr.sa_data, 0, ETHER_ADDR_LEN);
	}
	wireless_send_event(dev, SIOCGIWAP, &wreq, NULL);
}

void
ieee80211_notify_node_join(struct ieee80211_node *ni, int newassoc)
{
	struct ieee80211vap *vap = ni->ni_vap;
	struct net_device *dev = vap->iv_dev;
	union iwreq_data wreq;

	if (ni == vap->iv_bss)
		return;

	memset(&wreq, 0, sizeof(wreq));
	IEEE80211_ADDR_COPY(wreq.addr.sa_data, ni->ni_macaddr);
	wreq.addr.sa_family = ARPHRD_ETHER;
#ifdef ATH_SUPERG_XR
	if (vap->iv_xrvap && vap->iv_flags & IEEE80211_F_XR)
		dev = vap->iv_xrvap->iv_dev;
#endif
	wireless_send_event(dev, IWEVREGISTERED, &wreq, NULL);
}

void
ieee80211_notify_node_leave(struct ieee80211_node *ni)
{
	struct ieee80211vap *vap = ni->ni_vap;
	struct net_device *dev = vap->iv_dev;
	union iwreq_data wreq;

	if (ni == vap->iv_bss)
		return;

	/* fire off wireless event station leaving */
	memset(&wreq, 0, sizeof(wreq));
	IEEE80211_ADDR_COPY(wreq.addr.sa_data, ni->ni_macaddr);
	wreq.addr.sa_family = ARPHRD_ETHER;
	wireless_send_event(dev, IWEVEXPIRED, &wreq, NULL);
}

void
ieee80211_notify_sta_stats(struct ieee80211_node *ni)
{
	struct ieee80211vap *vap = ni->ni_vap;
	static const char *tag = "STA-TRAFFIC-STAT";
	struct net_device *dev = vap->iv_dev;
	union iwreq_data wreq;
	char buf[1024];

	snprintf(buf, sizeof(buf), "%s\nmac=" MAC_FMT "\nrx_packets=%u\nrx_bytes=%llu\n"
			"tx_packets=%u\ntx_bytes=%llu\n", tag,
			MAC_ADDR(ni->ni_macaddr), ni->ni_stats.ns_rx_data,
			(unsigned long long)ni->ni_stats.ns_rx_bytes,
			ni->ni_stats.ns_tx_data,
			(unsigned long long)ni->ni_stats.ns_tx_bytes);
	memset(&wreq, 0, sizeof(wreq));
	wreq.data.length = strlen(buf);
	wireless_send_event(dev, IWEVCUSTOM, &wreq, buf);
}

void
ieee80211_notify_scan_done(struct ieee80211vap *vap)
{
	struct net_device *dev = vap->iv_dev;
	union iwreq_data wreq;

	IEEE80211_DPRINTF(vap, IEEE80211_MSG_SCAN, "%s\n", "notify scan done");

	/* dispatch wireless event indicating scan completed */
	wreq.data.length = 0;
	wreq.data.flags = 0;
	wireless_send_event(dev, SIOCGIWSCAN, &wreq, NULL);
}

void
ieee80211_notify_replay_failure(struct ieee80211vap *vap,
	const struct ieee80211_frame *wh, const struct ieee80211_key *k,
	u_int64_t rsc)
{
	static const char *tag = "MLME-REPLAYFAILURE.indication";
	struct net_device *dev = vap->iv_dev;
	union iwreq_data wrqu;
	char buf[128];		/* XXX */

	IEEE80211_NOTE_MAC(vap, IEEE80211_MSG_CRYPTO, wh->i_addr2,
		"%s replay detected <keyix %d, rsc %llu >",
		k->wk_cipher->ic_name, k->wk_keyix,
		(unsigned long long)rsc);

	/* disabled for now due to bogus events for unknown reasons */
	return;

	/* TODO: needed parameters: count, keyid, key type, src address, TSC */
	snprintf(buf, sizeof(buf), "%s(keyid=%d %scast addr=" MAC_FMT ")", tag,
		k->wk_keyix,
		IEEE80211_IS_MULTICAST(wh->i_addr2) ?  "broad" : "uni",
		MAC_ADDR(wh->i_addr2));
	memset(&wrqu, 0, sizeof(wrqu));
	wrqu.data.length = strlen(buf);
	wireless_send_event(dev, IWEVCUSTOM, &wrqu, buf);
}
EXPORT_SYMBOL(ieee80211_notify_replay_failure);

void
ieee80211_notify_michael_failure(struct ieee80211vap *vap,
	const struct ieee80211_frame *wh, ieee80211_keyix_t keyix)
{
	static const char *tag = "MLME-MICHAELMICFAILURE.indication";
	struct net_device *dev = vap->iv_dev;
	union iwreq_data wrqu;
	char buf[128];		/* XXX */

	IEEE80211_NOTE_MAC(vap, IEEE80211_MSG_CRYPTO, wh->i_addr2,
		"Michael MIC verification failed <keyix %d>", keyix);
	vap->iv_stats.is_rx_tkipmic++;

	/* TODO: needed parameters: count, keyid, key type, src address, TSC */
	snprintf(buf, sizeof(buf), "%s(keyid=%d %scast addr=" MAC_FMT ")", tag,
		keyix, IEEE80211_IS_MULTICAST(wh->i_addr2) ?  "broad" : "uni",
		MAC_ADDR(wh->i_addr2));
	memset(&wrqu, 0, sizeof(wrqu));
	wrqu.data.length = strlen(buf);
	wireless_send_event(dev, IWEVCUSTOM, &wrqu, buf);
}
EXPORT_SYMBOL(ieee80211_notify_michael_failure);

/* This function might sleep. Therefore: 
 * Context: process
 *
 * Note that a successful call to this function does not guarantee that
 * the services provided by the requested module are available:
 *
 * "Note that a successful module load does not mean the module did not
 * then unload and exit on an error of its own. Callers must check that
 * the service they requested is now available not blindly invoke it."
 * http://kernelnewbies.org/documents/kdoc/kernel-api/r7338.html
 */
int
ieee80211_load_module(const char *modname)
{
#ifdef CONFIG_KMOD
	int rv;
	rv = request_module(modname);
	if (rv < 0)
		printk(KERN_ERR "failed to automatically load module: %s; " \
			"errno: %d\n", modname, rv);
	return rv;
#else /* CONFIG_KMOD */
	printk(KERN_ERR "Unable to load needed module: %s; no support for " \
			"automatic module loading\n", modname);
	return -ENOSYS;
#endif /* CONFIG_KMOD */
}


static struct proc_dir_entry *proc_madwifi;
static int proc_madwifi_count = 0;

static int
proc_read_nodes(struct ieee80211vap *vap, char *buf, int space)
{
	char *p = buf;
	struct ieee80211_node *ni;
	struct ieee80211_node_table *nt = (struct ieee80211_node_table *) &vap->iv_ic->ic_sta;

	IEEE80211_NODE_TABLE_LOCK_IRQ(nt);
	TAILQ_FOREACH(ni, &nt->nt_node, ni_list) {
		/* Assume each node needs 500 bytes */
		if (buf + space < p + 500)
			break;

		if (ni->ni_vap == vap &&
		    0 != memcmp(vap->iv_myaddr, ni->ni_macaddr, IEEE80211_ADDR_LEN)) {
			struct timespec t;
			jiffies_to_timespec(jiffies - ni->ni_last_rx, &t);
			p += sprintf(p, "macaddr: <" MAC_FMT ">\n", MAC_ADDR(ni->ni_macaddr));
			p += sprintf(p, " rssi %d\n", ni->ni_rssi);

			p += sprintf(p, " last_rx %ld.%06ld\n",
				     t.tv_sec, t.tv_nsec / 1000);

		}
        }
	IEEE80211_NODE_TABLE_UNLOCK_IRQ(nt);
	return (p - buf);
}

static ssize_t
proc_ieee80211_read(struct file *file, char __user *buf, size_t len, loff_t *offset)
{
	loff_t pos = *offset;
	struct proc_ieee80211_priv *pv = (struct proc_ieee80211_priv *) file->private_data;

	if (!pv->rbuf)
		return -EINVAL;
	if (pos < 0)
		return -EINVAL;
	if (pos > pv->rlen)
		return -EFAULT;
	if (len > pv->rlen - pos)
		len = pv->rlen - pos;
	if (copy_to_user(buf, pv->rbuf + pos, len))
		return -EFAULT;
	*offset = pos + len;
	return len;
}

static int
proc_ieee80211_open(struct inode *inode, struct file *file)
{
	struct proc_ieee80211_priv *pv = NULL;
	struct proc_dir_entry *dp = PDE(inode);
	struct ieee80211vap *vap = dp->data;

	if (!(file->private_data = kmalloc(sizeof(struct proc_ieee80211_priv), GFP_KERNEL)))
		return -ENOMEM;
	/* initially allocate both read and write buffers */
	pv = (struct proc_ieee80211_priv *) file->private_data;
	memset(pv, 0, sizeof(struct proc_ieee80211_priv));
	pv->rbuf = vmalloc(MAX_PROC_IEEE80211_SIZE);
	if (!pv->rbuf) {
		kfree(pv);
		return -ENOMEM;
	}
	pv->wbuf = vmalloc(MAX_PROC_IEEE80211_SIZE);
	if (!pv->wbuf) {
		vfree(pv->rbuf);
		kfree(pv);
		return -ENOMEM;
	}
	memset(pv->wbuf, 0, MAX_PROC_IEEE80211_SIZE);
	memset(pv->rbuf, 0, MAX_PROC_IEEE80211_SIZE);
	pv->max_wlen = MAX_PROC_IEEE80211_SIZE;
	pv->max_rlen = MAX_PROC_IEEE80211_SIZE;
	/* now read the data into the buffer */
	pv->rlen = proc_read_nodes(vap, pv->rbuf, MAX_PROC_IEEE80211_SIZE);
	return 0;
}

static ssize_t
proc_ieee80211_write(struct file *file, const char __user *buf, size_t len, loff_t *offset)
{
	loff_t pos = *offset;
	struct proc_ieee80211_priv *pv =
		(struct proc_ieee80211_priv *) file->private_data;

	if (!pv->wbuf)
		return -EINVAL;
	if (pos < 0)
		return -EINVAL;
	if (pos >= pv->max_wlen)
		return 0;
	if (len > pv->max_wlen - pos)
		len = pv->max_wlen - pos;
	if (copy_from_user(pv->wbuf + pos, buf, len))
		return -EFAULT;
	if (pos + len > pv->wlen)
		pv->wlen = pos + len;
	*offset = pos + len;

	return len;
}

static int
proc_ieee80211_close(struct inode *inode, struct file *file)
{
	struct proc_ieee80211_priv *pv =
		(struct proc_ieee80211_priv *) file->private_data;
	if (pv->rbuf)
		vfree(pv->rbuf);
	if (pv->wbuf)
		vfree(pv->wbuf);
	kfree(pv);
	return 0;
}

static struct file_operations proc_ieee80211_ops = {
	.read = proc_ieee80211_read,
	.write = proc_ieee80211_write,
	.open = proc_ieee80211_open,
	.release = proc_ieee80211_close,
};

//Begin Dheeraj addition
// read from log_meas[] to page
static int proc_meas_read(char *page, char **start, off_t off,int count, int *eof, void *data){
	char *p;
	struct ieee80211vap *local;
	int i;
	meas_log_t *l1;
	char logbuf[200];

	int unit_of_write;
	int num2print;
	unsigned long off_l;
	int len;
	int index;
	int entries;
	int wcnt;

	p = page;
	local = (struct ieee80211vap *)data;
	unit_of_write = 200;
	off_l = off;
	len=0;
	index = 0;
	entries = 0;
	wcnt =0;

	//printk("Inside proc_meas_read\n");

	//No entries to print
	if(local->meas_tail == local->meas_head){
		*eof =1;
		return 0;
	}
	if (off != 0) {
		*eof = 1;
		return 0;
	}

	num2print = count/unit_of_write;

	if(local->meas_head < local->meas_tail)
		entries = local->meas_tail - local->meas_head;
	else 
		entries = NUM_MEAS_LOG - (local->meas_head - local->meas_tail);
	
	if (num2print < entries){
		wcnt = num2print;
	}
	else{
		wcnt = entries;
	}
	
	// Write equal size lines for each log entry
	for(i = 0; i < wcnt; i++) {
		index = local->meas_head;
		//	  if(index >= local->meas_tail) { break; }
		l1 = &(local->log_meas[index]);
		//Ashutosh-Nirav Addition
		if ((int)l1->type == 0 && (int)l1->subtype == 0 && (int)l1->len==0)
		{
			local->num_in_meas--;
			local->meas_head = succ(local->meas_head,NUM_MEAS_LOG);
			continue;
		}
		//len = sprintf(logbuf, "t=%06lu.%06lu ts=%u fty=%d fsty=%d ln=%d sq=%d er=%d sl=%d sg=%d rt=%d a1=" MACSTR " a2=" MACSTR " a3=" MACSTR " h=%d t=%d",l1->time/1000000UL, l1->time%1000000UL, l1->mtime, (int)l1->type, (int)l1->subtype, l1->len, (int)l1->seq_no,l1->error, (int)l1->silence, (int)l1->signal, (int)l1->rate, MAC2STR(l1->addr1), MAC2STR(l1->addr2), MAC2STR(l1->addr3),local->meas_head, local->meas_tail);
		
		len = sprintf(logbuf, "t=%06lu.%06lu ts=%u fty=%d fsty=%d ln=%d sq=%d er=%d sl=%d sg=%d rt=%d a1=" MACSTR " a2=" MACSTR " h=%d t=%d",l1->time/1000000UL, l1->time%1000000UL, l1->mtime, (int)l1->type, (int)l1->subtype, l1->len, (int)l1->seq_no,l1->error, (int)l1->silence, (int)l1->signal, (int)l1->rate, MAC2STR(l1->addr1), MAC2STR(l1->addr2), local->meas_head, local->meas_tail);

		//len = sprintf(logbuf,"Offset= %llu",l1->timestamp_offset);

		// Ensure space for '\n'
		if(len > unit_of_write-1) {
			p += sprintf(p, "len=%d, unit_of_write=%d\n", len, unit_of_write);
			return (p - page);
		}
		// Fill up remaining space with ' ', and a last '\n'
		while(len < unit_of_write-1){
			 logbuf[len] = ' '; len++;
		}
		logbuf[len] = '\n'; len++;

		strncpy(p, logbuf, len);
		p += len;
		local->num_in_meas--;
		local->meas_head = succ(local->meas_head,NUM_MEAS_LOG);
	} // End for(i)
	*eof = 1;
	return (p - page);

} // End proc_meas_read()


// read measstat from local to page
static int proc_measstat_read(char *page, char **start, off_t off,int count, int *eof, void *data){
	char *p;
	struct ieee80211vap *local;
	int entries;

	p = page;
	local = (struct ieee80211vap *) data;
	entries =0;

	if (off != 0) {
		*eof = 1;
		return 0;
	}

	if(local->meas_head <= local->meas_tail)
		entries = local->meas_tail - local->meas_head;
	else 
		entries = NUM_MEAS_LOG - (local->meas_head - local->meas_tail);
	
	p += sprintf(p, "head=%d\n", local->meas_head);
	p += sprintf(p, "tail=%d\n", local->meas_tail);
	p += sprintf(p, "entries=%d\n", entries);
	p += sprintf(p, "num_in_meas=%d\n", local->num_in_meas);
		
	return (p - page);
} // End proc_measstat_read()


// write measstat data from argbuf to buffer(from user to kernel space)
static int proc_measstat_write(struct file *file, const char *argbuf, unsigned long count, void *data){
	struct ieee80211vap *local;
	char buf[256];
	
	local = (struct ieee80211vap *) data;

	if(count > sizeof(buf)-1) {
		printk(KERN_DEBUG "%s: measlogstat writing too much data\n", local->iv_proc->name);
		return -EFAULT;
	}
	
	if(copy_from_user(buf, argbuf, count)) {
		printk(KERN_DEBUG "%s: measlogstat copy_from_user failed\n", local->iv_proc->name);
		return -EFAULT;
	}
	buf[count] = 0; // terminate with a null character
	
	if(strncmp(buf, "reset", strlen("reset")) == 0) {
		local->meas_head = 0;
		local->meas_tail = 0;
		local->num_in_meas = 0;
	}
	else {
		printk(KERN_DEBUG "%s: measlogstat unknown format\n", local->iv_proc->name);
		return -EFAULT;		//remember to search where this constant has been defined(part of hostap, can create trouble)
	}
	
	return count;
}
// End proc_measstat_write()
// read meas_broadcast from local to page
static int proc_measbroadcast_read(char *page, char **start, off_t off, int count, int *eof, void *data){
	char *p;
	struct ieee80211vap *local_vap;

	p = page;
	local_vap = (struct ieee80211vap *) data;

	if (off != 0) {
		*eof = 1;
		return 0;
	}
	p += sprintf(p, "broadcast=%d\n", local_vap->broadcast);
	return (p - page);
} // End proc_measstat_read()

// read meas_broadcast value from user area and set the local->broadcast value accordingly
static int proc_measbroadcast_write(struct file *file, const char *argbuf, unsigned long count, void *data){
	struct ieee80211vap *local_vap;
	char buf[256];
	
	local_vap = (struct ieee80211vap *) data;
	if(count > sizeof(buf)-1) {
		printk(KERN_DEBUG "%s: measbroadcast writing too much data\n", local_vap->iv_proc->name);
		return -EFAULT;
	}
	
	if(copy_from_user(buf, argbuf, count)) {
		printk(KERN_DEBUG "%s: measbroadcast copy_from_user failed\n", local_vap->iv_proc->name);
		return -EFAULT;
	}
	buf[count] = 0; // terminate with a null character
	
	if(strncmp(buf, "broadcast=0", strlen("broadcast=0")) == 0) {
		local_vap->broadcast = 0;
	}
	else if (strncmp(buf, "broadcast=1", strlen("broadcast=1")) == 0) {
		local_vap->broadcast = 1;
	}
	else {
		printk(KERN_DEBUG "%s: measbroadcast unknown format\n", local_vap->iv_proc->name);
		return -EFAULT;
	}

	return count;
}
// End Dheeraj addition

//Ashutosh-Nirav change start

long custom_atol_break_atnonum(const char * str)
{
	long i=0;
	long j=0;
	int nonum=0;
	while(*str!='\0')
	{
		switch(*str)
		{
		case '1':i=1;
			break;
		case '2':i=2;
			break;
		case '3':i=3;
			break;
		case '4':i=4;
			break;
		case '5':i=5;
			break;
		case '6':i=6;
			break;
		case '7':i=7;
			break;
		case '8':i=8;
			break;
		case '9':i=9;
			break;
		case '0':i=0;
			break;
		default: nonum=1;
			break;
		}
	if (nonum==1)
		break;
	j=j*10+i;
	str++;
	//printf("J= %lu\n",j);
	}
	
	return j;
}	

static int fractel_log_read(char *page, char **start, off_t off,int count, int *eof, void *data)
{
	char p[255];
	struct ieee80211vap *local;
	int len;

	static uint32_t cnt=0; //added for logging get stopped in between
	
	if (off != 0) {
		*eof = 1;
		return 0;
	}
	
	local = (struct ieee80211vap *)data;
	
	len=sprintf(p, "%s\n", local->fractel_log_ptr + (local->fractel_log_read_entry*255));
	if (len<10)
	{
		//No entries yet in log.
		*eof = 1;
		return 0;
	}
	//if ((unsigned long)custom_atol_break_atnonum(p+1) < local->last_read_nowrap_entry)
	if ((unsigned long)custom_atol_break_atnonum(p+1) < local->last_read_nowrap_entry && cnt < 50000) //--vs change
	{
		//No new entry after the last read of proc. Return nothing.
		*eof = 1;
		cnt++; //-- vs change
		return 0;
	}
	else
	{
		local->fractel_log_read_entry++;
		if (local->fractel_log_read_entry >= MAX_LOG_SIZE)
		{
			local->fractel_log_read_entry = (local->fractel_log_read_entry) % MAX_LOG_SIZE;
		}
		local->last_read_nowrap_entry = (unsigned long)custom_atol_break_atnonum(p+1);
		strncpy(page, p, len);
		*eof = 1;
		cnt = 0; //-- vs change
		return (len);
	}
	*eof = 1;
	return 0;
}

//vl-change start
static int fractel_routing_entries_read(char *page, char **start, off_t off,int count, int *eof, void *data)
{
	char p[255];
	struct ieee80211vap *local;
	int len;
	
	if (off != 0) {
		//printk("off -- returning bcos off non-zero\n");
		*eof = 1;
		return 0;
	}
	
	local = (struct ieee80211vap *)data;
	
	len=sprintf(p, "%s\n", local->fractel_routing_ptr + (local->fractel_routing_entry*255));
	if (len<10)
	{
		//printk("len %d -- returning since len less than 10\n",len);
		//No entries yet in log.
		*eof = 1;
		return 0;
	}
	if ((unsigned long)custom_atol_break_atnonum(p) < local->last_routing_read_nowrap_entry)
	{
		//No new entry after the last read of proc. Return nothing.
		//printk("len %d -- returning some local understable stuff\n",len);
		*eof = 1;
		return 0;
	}
	else
	{
		local->fractel_routing_entry++;
		if (local->fractel_routing_entry >= MAX_LOG_SIZE)
		{
			local->fractel_routing_entry = (local->fractel_routing_entry) % MAX_LOG_SIZE;
		}
		local->last_routing_read_nowrap_entry = (unsigned long)custom_atol_break_atnonum(p);
		strncpy(page, p, len);
		*eof = 1;
		//printk("entered %s",p);
		return (len);
	}
	*eof = 1;
	return 0;
}
//vl-change end

static int proc_fractel_config_read(char *page, char **start, off_t off, int count, int *eof, void *data){
	char *p;
	struct ieee80211vap *local_vap;

	p = page;
	local_vap = (struct ieee80211vap *) data;

	if (off != 0) {
		*eof = 1;
		return 0;
	}
	p += sprintf(p, "interval=%d\nnode_id=%d\nself_node_ip=%s\nno_of_control_slots=%d\nno_of_contention_slots=%d\nno_data_slots=%d\nmax_no_of_rssi_values=%d\nrssi_sense_timeout=%d\nroot_ip=%s\nerror_rate=%d\nfractel_data_rate=%d\ncustom_topology=%d\nparent=%d,frame_length=%d\n,slot1=%d\nslot2=%d\n,slot3=%d\nslot4=%d\nslot5=%d",INTERVAL, NODE_ID, SELF_NODE_ID, NO_OF_CONTROL_SLOTS, NO_OF_CONTENTION_SLOTS, NO_OF_DATA_SLOTS, MAX_NO_OF_RSSI_VALUES, RSSI_SENSE_TIMEOUT,ROOT_IP,ERROR_RATE,fractel_data_rate,custom_topology,parent,frame_length,slot1,slot2,slot3,slot4,slot5);
	*eof=1;
	return (p - page);
} 

static int proc_fractel_config_write(struct file *file, const char *argbuf, unsigned long count, void *data){
	struct ieee80211vap *local_vap;
	char buf[1000];
	char fractel_config_var[100];
	char fractel_config_value[20];
	
	int end_of_proc_entry=0;
	int i=0;
	int j=0;
	int in_value=0;
	extern int fractel_operation_started;
	
	printf("proc write \n\n");
	local_vap = (struct ieee80211vap *) data;
	if(count > sizeof(buf)-1) {
		printk(KERN_DEBUG "%s: fractel_conifg writing too much data\n", local_vap->iv_proc->name);
		return -EFAULT;
	}
	
	if(copy_from_user(buf, argbuf, count)) {
		printk(KERN_DEBUG "%s: fractel_conifg copy_from_user failed\n", local_vap->iv_proc->name);
		return -EFAULT;
	}
	buf[count] = 0; // terminate with a null character
	if (fractel_operation_started == 1)
	{
		return count;
	}
	
	while (!end_of_proc_entry)
	{
		if (buf[i] == '=')
		{
			fractel_config_var[j]='\0';
			in_value=1;
			
			j=0;
		}
		else if (buf[i] == '\n')
		{
			in_value=0;	
			fractel_config_value[j]='\0';
			
			j=0;
			//compare logic
			if (strncmp(fractel_config_variables[0],fractel_config_var,strlen(fractel_config_variables[0]))==0)
			{
				NODE_ID=custom_atol_break_atnonum(fractel_config_value);
				printf("NODE_ID : %d \n",NODE_ID);
			}
			if (strncmp(fractel_config_variables[1],fractel_config_var,strlen(fractel_config_variables[1]))==0)
			{
				strcpy(SELF_NODE_ID,fractel_config_value);
				printf("SELF_NODE_ID : %s \n",SELF_NODE_ID);
			}
			if (strncmp(fractel_config_variables[2],fractel_config_var,strlen(fractel_config_variables[2]))==0)
			{
				NO_OF_CONTROL_SLOTS=custom_atol_break_atnonum(fractel_config_value);
				printf("NO_OF_CONTROL_SLOTS : %d \n",NO_OF_CONTROL_SLOTS);
			}
			if (strncmp(fractel_config_variables[3],fractel_config_var,strlen(fractel_config_variables[3]))==0)
			{
				NO_OF_CONTENTION_SLOTS=custom_atol_break_atnonum(fractel_config_value);
				printf("NO_OF_CONTENTION_SLOTS : %d \n",NO_OF_CONTENTION_SLOTS);
			}
			if (strncmp(fractel_config_variables[4],fractel_config_var,strlen(fractel_config_variables[4]))==0)
			{
				NO_OF_DATA_SLOTS=custom_atol_break_atnonum(fractel_config_value);
				printf("NO_OF_DATA_SLOTS : %d\n",NO_OF_DATA_SLOTS);
			}
			if (strncmp(fractel_config_variables[5],fractel_config_var,strlen(fractel_config_variables[5]))==0)
			{
				MAX_NO_OF_RSSI_VALUES=custom_atol_break_atnonum(fractel_config_value);
				printf("MAX_NO_OF_RSSI_VALUES : %d\n",MAX_NO_OF_RSSI_VALUES);
			}
			if (strncmp(fractel_config_variables[6],fractel_config_var,strlen(fractel_config_variables[6]))==0)
			{
				RSSI_SENSE_TIMEOUT=custom_atol_break_atnonum(fractel_config_value);
				printf("RSSI_SENSE_TIMEOUT : %d\n",RSSI_SENSE_TIMEOUT);
			}
			if (strncmp(fractel_config_variables[7],fractel_config_var,strlen(fractel_config_variables[7]))==0)
			{
				INTERVAL=custom_atol_break_atnonum(fractel_config_value);
				printf("INTERVAL : %d \n",INTERVAL);
			}
			if (strncmp(fractel_config_variables[8],fractel_config_var,strlen(fractel_config_variables[8]))==0)
			{
				strcpy(ROOT_IP,fractel_config_value);
				printf("ROOT_IP : %s \n",ROOT_IP);
			}if (strncmp(fractel_config_variables[9],fractel_config_var,strlen(fractel_config_variables[9]))==0)
			{
				ERROR_RATE=custom_atol_break_atnonum(fractel_config_value);
				printf("ERROR_RATE : %d \n",ERROR_RATE);
			}if (strncmp(fractel_config_variables[10],fractel_config_var,strlen(fractel_config_variables[10]))==0)
			{
				fractel_data_rate=custom_atol_break_atnonum(fractel_config_value);
				printf("fractel_data_rate : %d \n",fractel_data_rate);
			}
			if (strncmp(fractel_config_variables[11],fractel_config_var,strlen(fractel_config_variables[11]))==0)
			{
				custom_topology=custom_atol_break_atnonum(fractel_config_value);
				printf("custom_topology : %d \n",custom_topology);
			}
			if (strncmp(fractel_config_variables[12],fractel_config_var,strlen(fractel_config_variables[12]))==0)
			{
				parent=custom_atol_break_atnonum(fractel_config_value);
				printf("parent : %u \n",parent);
			}
			if (strncmp(fractel_config_variables[13],fractel_config_var,strlen(fractel_config_variables[13]))==0)
			{
				frame_length=custom_atol_break_atnonum(fractel_config_value);
				printf("frame_length : %u \n",frame_length);
			}
			if (strncmp(fractel_config_variables[14],fractel_config_var,strlen(fractel_config_variables[14]))==0)
			{
				slot1=custom_atol_break_atnonum(fractel_config_value);
				printf("slot1 : %u \n",slot1);
			}
			if (strncmp(fractel_config_variables[15],fractel_config_var,strlen(fractel_config_variables[15]))==0)
			{
				slot2=custom_atol_break_atnonum(fractel_config_value);
				printf("slot2 : %u \n",slot2);
			}
			if (strncmp(fractel_config_variables[16],fractel_config_var,strlen(fractel_config_variables[16]))==0)
			{
				slot3=custom_atol_break_atnonum(fractel_config_value);
				printf("slot3 : %u \n",slot3);
			}
			if (strncmp(fractel_config_variables[17],fractel_config_var,strlen(fractel_config_variables[17]))==0)
			{
				slot4=custom_atol_break_atnonum(fractel_config_value);
				printf("slot4 : %u \n",slot4);
			}
			if (strncmp(fractel_config_variables[18],fractel_config_var,strlen(fractel_config_variables[18]))==0)
			{
				slot5=custom_atol_break_atnonum(fractel_config_value);
				printf("slot5 : %u \n",slot5);
			}
		}
		else
		{
			if (in_value == 0)
			{
				fractel_config_var[j]=buf[i];
			}
			else
			{
				fractel_config_value[j]=buf[i];
			}
			j++;
		}
		i++;	
		if(count==i)
		{
			end_of_proc_entry=1;
		}
	}
	NO_OF_SLOTS = NO_OF_CONTROL_SLOTS + NO_OF_CONTENTION_SLOTS + NO_OF_DATA_SLOTS; 
	return count;
}
// Ashutosh-Nirav change End

#ifdef IEEE80211_DEBUG
static int
IEEE80211_SYSCTL_DECL(ieee80211_sysctl_debug, ctl, write, filp, buffer,
	lenp, ppos)
{
	struct ieee80211vap *vap = ctl->extra1;
	u_int val;
	int ret;

	ctl->data = &val;
	ctl->maxlen = sizeof(val);
	if (write) {
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
		if (ret == 0) {
			vap->iv_debug 		= (val & ~IEEE80211_MSG_IC);
			vap->iv_ic->ic_debug 	= (val &  IEEE80211_MSG_IC);
		}
	} else {
		/* VAP specific and 'global' debug flags */
		val = vap->iv_debug | vap->iv_ic->ic_debug;
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
	}
	return ret;
}
#endif /* IEEE80211_DEBUG */

static int
IEEE80211_SYSCTL_DECL(ieee80211_sysctl_dev_type, ctl, write, filp, buffer,
	lenp, ppos)
{
	struct ieee80211vap *vap = ctl->extra1;
	u_int val;
	int ret;

	ctl->data = &val;
	ctl->maxlen = sizeof(val);
	if (write) {
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
		if (ret == 0 && vap->iv_opmode == IEEE80211_M_MONITOR) {
			if (val == ARPHRD_IEEE80211_RADIOTAP ||
			    val == ARPHRD_IEEE80211 ||
			    val == ARPHRD_IEEE80211_PRISM ||
			    val == ARPHRD_IEEE80211_ATHDESC) {
				vap->iv_dev->type = val;
			}
		}
	} else {
		val = vap->iv_dev->type;
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
	}
	return ret;
}

static int
IEEE80211_SYSCTL_DECL(ieee80211_sysctl_monitor_nods_only, ctl, write, filp, buffer,
	lenp, ppos)
{
	struct ieee80211vap *vap = ctl->extra1;
	u_int val;
	int ret;

	ctl->data = &val;
	ctl->maxlen = sizeof(val);
	if (write) {
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
		if (ret == 0)
			vap->iv_monitor_nods_only = val;
	} else {
		val = vap->iv_monitor_nods_only;
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
	}
	return ret;
}

static int
IEEE80211_SYSCTL_DECL(ieee80211_sysctl_monitor_txf_len, ctl, write, filp, buffer,
	lenp, ppos)
{
	struct ieee80211vap *vap = ctl->extra1;
	u_int val;
	int ret;

	ctl->data = &val;
	ctl->maxlen = sizeof(val);
	if (write) {
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
		if (ret == 0)
			vap->iv_monitor_txf_len = val;
	} else {
		val = vap->iv_monitor_txf_len;
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
	}
	return ret;
}

static int
IEEE80211_SYSCTL_DECL(ieee80211_sysctl_monitor_phy_errors, ctl, write, filp, buffer,
	lenp, ppos)
{
	struct ieee80211vap *vap = ctl->extra1;
	u_int val;
	int ret;

	ctl->data = &val;
	ctl->maxlen = sizeof(val);
	if (write) {
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
		if (ret == 0)
			vap->iv_monitor_phy_errors = val;
	} else {
		val = vap->iv_monitor_phy_errors;
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
	}
	return ret;
}

static int
IEEE80211_SYSCTL_DECL(ieee80211_sysctl_monitor_crc_errors, ctl, write, filp, buffer,
	lenp, ppos)
{
	struct ieee80211vap *vap = ctl->extra1;
	u_int val;
	int ret;

	ctl->data = &val;
	ctl->maxlen = sizeof(val);
	if (write) {
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
		if (ret == 0)
			vap->iv_monitor_crc_errors = val;
	} else {
		val = vap->iv_monitor_crc_errors;
		ret = IEEE80211_SYSCTL_PROC_DOINTVEC(ctl, write, filp, buffer,
			lenp, ppos);
	}
	return ret;
}

static const ctl_table ieee80211_sysctl_template[] = {
#ifdef IEEE80211_DEBUG
	{ .ctl_name	= CTL_AUTO,
	  .procname	= "debug",
	  .mode		= 0644,
	  .proc_handler	= ieee80211_sysctl_debug
	},
#endif
	{ .ctl_name	= CTL_AUTO,
	  .procname	= "dev_type",
	  .mode		= 0644,
	  .proc_handler	= ieee80211_sysctl_dev_type
	},
	{ .ctl_name	= CTL_AUTO,
	  .procname	= "monitor_nods_only",
	  .mode		= 0644,
	  .proc_handler	= ieee80211_sysctl_monitor_nods_only
	},
	{ .ctl_name	= CTL_AUTO,
	  .procname	= "monitor_txf_len",
	  .mode		= 0644,
	  .proc_handler	= ieee80211_sysctl_monitor_txf_len
	},
	{ .ctl_name	= CTL_AUTO,
	  .procname	= "monitor_phy_errors",
	  .mode		= 0644,
	  .proc_handler = ieee80211_sysctl_monitor_phy_errors
	},
	{ .ctl_name	= CTL_AUTO,
	  .procname	= "monitor_crc_errors",
	  .mode		= 0644,
	  .proc_handler = ieee80211_sysctl_monitor_crc_errors
	},
	/* NB: must be last entry before NULL */
	{ .ctl_name	= CTL_AUTO,
	  .procname	= "%parent",
	  .maxlen	= IFNAMSIZ,
	  .mode		= 0444,
	  .proc_handler	= proc_dostring
	},
	{ 0 }
};

void
ieee80211_virtfs_latevattach(struct ieee80211vap *vap)
{
	int i, space;
	char *devname = NULL;
	struct ieee80211_proc_entry *tmp = NULL;

	struct proc_dir_entry *measlogstat; // Dheeraj addition
	struct proc_dir_entry *measbroadcast; // Dheeraj addition
	
	struct proc_dir_entry *fractel_config; // Ashutosh-Nirav addition

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
	int ret;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,21)
	ret = sysfs_create_group(&vap->iv_dev->dev.kobj, &ieee80211_attr_grp);
#else
	ret = sysfs_create_group(&vap->iv_dev->class_dev.kobj, &ieee80211_attr_grp);
#endif
	if (ret) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,21)
		sysfs_remove_group(&vap->iv_dev->dev.kobj, &ieee80211_attr_grp);
#else
		sysfs_remove_group(&vap->iv_dev->class_dev.kobj, &ieee80211_attr_grp);
#endif
		printk("%s: %s - unable to create sysfs attribute group\n", 
				__func__, vap->iv_dev->name);
		return;
	}
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17) */

	space = 5 * sizeof(struct ctl_table) + sizeof(ieee80211_sysctl_template);
	vap->iv_sysctls = kmalloc(space, GFP_KERNEL);
	if (vap->iv_sysctls == NULL) {
		printk("%s: no memory for sysctl table!\n", __func__);
		return;
	}

	/*
	 * Reserve space for the device name outside the net_device structure
	 * so that if the name changes we know what it used to be. 
	 */
	devname = kmalloc((strlen(vap->iv_dev->name) + 1) * sizeof(char), GFP_KERNEL);
	if (devname == NULL) {
		printk("%s: no memory for VAP name!\n", __func__);
		return;
	}
	strncpy(devname, vap->iv_dev->name, strlen(vap->iv_dev->name) + 1);

	/* setup the table */
	memset(vap->iv_sysctls, 0, space);
	vap->iv_sysctls[0].ctl_name = CTL_NET;
	vap->iv_sysctls[0].procname = "net";
	vap->iv_sysctls[0].mode = 0555;
	vap->iv_sysctls[0].child = &vap->iv_sysctls[2];
	/* [1] is NULL terminator */
	vap->iv_sysctls[2].ctl_name = CTL_AUTO;
	vap->iv_sysctls[2].procname = devname; /* XXX bad idea? */
	vap->iv_sysctls[2].mode = 0555;
	vap->iv_sysctls[2].child = &vap->iv_sysctls[4];
	/* [3] is NULL terminator */
	/* copy in pre-defined data */
	memcpy(&vap->iv_sysctls[4], ieee80211_sysctl_template,
		sizeof(ieee80211_sysctl_template));

	/* add in dynamic data references */
	for (i = 4; vap->iv_sysctls[i].procname; i++)
		if (vap->iv_sysctls[i].extra1 == NULL)
			vap->iv_sysctls[i].extra1 = vap;

	/* tack on back-pointer to parent device */
	vap->iv_sysctls[i-1].data = vap->iv_ic->ic_dev->name;	/* XXX? */

	/* and register everything */
	vap->iv_sysctl_header = ATH_REGISTER_SYSCTL_TABLE(vap->iv_sysctls);
	if (!vap->iv_sysctl_header) {
		printk("%s: failed to register sysctls!\n", vap->iv_dev->name);
		kfree(devname);
		kfree(vap->iv_sysctls);
		vap->iv_sysctls = NULL;
	}

	/* Ensure the base madwifi directory exists */
	if (!proc_madwifi && proc_net != NULL) {
		proc_madwifi = proc_mkdir("madwifi", proc_net);
		if (!proc_madwifi)
			printk(KERN_WARNING "Failed to mkdir /proc/net/madwifi\n");
	}

	/* Create a proc directory named after the VAP */
	if (proc_madwifi) {
		proc_madwifi_count++;
		vap->iv_proc = proc_mkdir(vap->iv_dev->name, proc_madwifi);
	}

	/* Create a proc entry listing the associated stations */
	ieee80211_proc_vcreate(vap, &proc_ieee80211_ops, "associated_sta");
	
	// Dheeraj addition
	create_proc_read_entry("meas_log", PROC_IEEE80211_PERM, vap->iv_proc,proc_meas_read, vap);
	
        measlogstat = create_proc_read_entry("meas_log_stat", PROC_IEEE80211_PERM, vap->iv_proc, proc_measstat_read, vap);
        measlogstat->write_proc = proc_measstat_write;

	
 	measbroadcast = create_proc_read_entry("meas_broadcast", PROC_IEEE80211_PERM, vap->iv_proc,proc_measbroadcast_read, vap);
	measbroadcast->write_proc = proc_measbroadcast_write;
        // End Dheeraj addition

	//Ashutosh-Nirav change start
	create_proc_read_entry("fractel_log", PROC_IEEE80211_PERM, vap->iv_proc, fractel_log_read, vap);
	create_proc_read_entry("fractel_routing_entries", PROC_IEEE80211_PERM, vap->iv_proc, fractel_routing_entries_read, vap);
	fractel_config = create_proc_read_entry("fractel_config", PROC_IEEE80211_PERM, vap->iv_proc,proc_fractel_config_read, vap);
	fractel_config->write_proc = proc_fractel_config_write;
	//Ashutosh-Nirav change End

	/* Recreate any other proc entries that have been registered */
	if (vap->iv_proc) {
		tmp = vap->iv_proc_entries;
		while (tmp) {
			if (!tmp->entry) {
				tmp->entry = create_proc_entry(tmp->name,
				PROC_IEEE80211_PERM, vap->iv_proc);
				tmp->entry->data = vap;
				tmp->entry->proc_fops = tmp->fileops;
			}
			tmp = tmp->next;
		}
	}
}

/* Frees all memory used for the list of proc entries */
void
ieee80211_proc_cleanup(struct ieee80211vap *vap)
{
	struct ieee80211_proc_entry *tmp = vap->iv_proc_entries;
	struct ieee80211_proc_entry *next = NULL;
	while (tmp) {
		next = tmp->next;
		kfree(tmp);
		tmp = next;
	}
}

/* Called by other modules to register a proc entry under the vap directory */
int
ieee80211_proc_vcreate(struct ieee80211vap *vap,
		struct file_operations *fileops, char *name)
{
	struct ieee80211_proc_entry *entry;
	struct ieee80211_proc_entry *tmp = NULL;

	/* Ignore if already in the list */
	if (vap->iv_proc_entries) {
		tmp = vap->iv_proc_entries;
		do {
			if (strcmp(tmp->name, name)==0)
				return -1;
			/* Check for end of list */
			if (!tmp->next)
				break;
			/* Otherwise move on */
			tmp = tmp->next;
		} while (1);
	}

	/* Create an item in our list for the new entry */
	entry = kmalloc(sizeof(struct ieee80211_proc_entry), GFP_KERNEL);
	if (entry == NULL) {
		printk("%s: no memory for new proc entry (%s)!\n", __func__,
				name);
		return -1;
	}

	/* Replace null fileops pointers with our standard functions */
	if (!fileops->open)
		fileops->open = proc_ieee80211_open;
	if (!fileops->release)
		fileops->release = proc_ieee80211_close;
	if (!fileops->read)
		fileops->read = proc_ieee80211_read;
	if (!fileops->write)
		fileops->write = proc_ieee80211_write;

	/* Create the entry record */
	entry->name = name;
	entry->fileops = fileops;
	entry->next = NULL;
	entry->entry = NULL;

	/* Create the actual proc entry */
	if (vap->iv_proc) {
		entry->entry = create_proc_entry(entry->name,
				PROC_IEEE80211_PERM, vap->iv_proc);
		entry->entry->data = vap;
		entry->entry->proc_fops = entry->fileops;
	}

	/* Add it to the list */
	if (!tmp) {
		/* Add to the start */
		vap->iv_proc_entries = entry;
	} else {
		/* Add to the end */
		tmp->next = entry;
	}

	return 0;
}
EXPORT_SYMBOL(ieee80211_proc_vcreate);

void
ieee80211_virtfs_vdetach(struct ieee80211vap *vap)
{
	struct ieee80211_proc_entry *tmp=NULL;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,21)
	sysfs_remove_group(&vap->iv_dev->dev.kobj, &ieee80211_attr_grp);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
	sysfs_remove_group(&vap->iv_dev->class_dev.kobj, &ieee80211_attr_grp);
#endif

	if (vap->iv_sysctl_header) {
		unregister_sysctl_table(vap->iv_sysctl_header);
		vap->iv_sysctl_header = NULL;
	}

	if (vap->iv_proc) {
		/* Remove child proc entries but leave them in the list */
		tmp = vap->iv_proc_entries;
		while (tmp) {
			if (tmp->entry) {
				remove_proc_entry(tmp->name, vap->iv_proc);
				tmp->entry = NULL;
			}
			tmp = tmp->next;
		}
		
		
		//Dheeraj addition
		remove_proc_entry("meas_log", vap->iv_proc); 
                remove_proc_entry("meas_log_stat", vap->iv_proc);
		remove_proc_entry("meas_broadcast", vap->iv_proc);
		//Dheeraj addition end	
		
		//Ashutosh-Nirav change start
		remove_proc_entry("fractel_config", vap->iv_proc);	
		remove_proc_entry("fractel_log", vap->iv_proc);
		//Ashutosh-Nirav change end
		//vl change start
		remove_proc_entry("fractel_routing_entries", vap->iv_proc);
		//vl change end

		remove_proc_entry(vap->iv_proc->name, proc_madwifi);
		if (proc_madwifi_count == 1) {
			remove_proc_entry("madwifi", proc_net);
			proc_madwifi = NULL;
		}
		proc_madwifi_count--;
	}

	if (vap->iv_sysctls && vap->iv_sysctls[2].procname) {
		kfree(vap->iv_sysctls[2].procname);
		vap->iv_sysctls[2].procname = NULL;
	}

	if (vap->iv_sysctls) {
		kfree(vap->iv_sysctls);
		vap->iv_sysctls = NULL;
	}
}

/* Function to handle the device event notifications.
 * If the event is a NETDEV_CHANGENAME, and is for an interface
 * we are taking care of, then we want to remove its existing 
 * proc entries (which now have the wrong names) and add
 * new, correct, entries.
 */
static int
ieee80211_rcv_dev_event(struct notifier_block *this, unsigned long event,
	void *ptr)
{
	struct net_device *dev = (struct net_device *) ptr;
	
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,29)
        if (!dev || dev->open != &ieee80211_open)
                return 0;
#else
       if (!dev || dev->netdev_ops->ndo_open != &ieee80211_open)
               return 0;
#endif
	switch (event) {
	case NETDEV_CHANGENAME:
		ieee80211_virtfs_vdetach(netdev_priv(dev));
		ieee80211_virtfs_latevattach(netdev_priv(dev));
		return NOTIFY_DONE;
	default:
		break;
	}
	return 0;
}

static struct notifier_block ieee80211_event_block = {
	.notifier_call = ieee80211_rcv_dev_event
};

/*
 * Module glue.
 */
#include "release.h"
static char *version = RELEASE_VERSION;
static char *dev_info = "wlan";

MODULE_AUTHOR("Errno Consulting, Sam Leffler");
MODULE_DESCRIPTION("802.11 wireless LAN protocol support");
#ifdef MODULE_VERSION
MODULE_VERSION(RELEASE_VERSION);
#endif
#ifdef MODULE_LICENSE
MODULE_LICENSE("Dual BSD/GPL");
#endif

extern	void ieee80211_auth_setup(void);

static int __init
init_wlan(void)
{
  	register_netdevice_notifier(&ieee80211_event_block);
	printk(KERN_INFO "%s: %s\n", dev_info, version);
	return 0;
}
module_init(init_wlan);

static void __exit
exit_wlan(void)
{
  	unregister_netdevice_notifier(&ieee80211_event_block);
	printk(KERN_INFO "%s: driver unloaded\n", dev_info);
}
module_exit(exit_wlan);
