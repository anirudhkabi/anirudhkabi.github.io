#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xc0196af1, "struct_module" },
	{ 0xb80330df, "kmalloc_caches" },
	{ 0x3075477, "ieee80211_print_essid" },
	{ 0x717bb953, "ieee80211_chan2mode" },
	{ 0xb95f9521, "ieee80211_scanner_unregister_all" },
	{ 0x900e0d6, "_spin_lock" },
	{ 0x2c1b6439, "ieee80211_saveie" },
	{ 0xed15efff, "ieee80211_chan2ieee" },
	{ 0x21caae40, "ieee80211_scanner_register" },
	{ 0xeaa456ed, "_spin_lock_irqsave" },
	{ 0x897bc6da, "ieee80211_bg_scan" },
	{ 0x7d11c268, "jiffies" },
	{ 0x236a0fbe, "ieee80211_note_mac" },
	{ 0xde0bdcff, "memset" },
	{ 0xc57c2ac5, "ieee80211_sta_join" },
	{ 0xdd132261, "printk" },
	{ 0xfaef0ed, "__tasklet_schedule" },
	{ 0x27147e64, "_spin_unlock_irqrestore" },
	{ 0x9545af6d, "tasklet_init" },
	{ 0xf347c0ed, "ieee80211_start_scan" },
	{ 0x82072614, "tasklet_kill" },
	{ 0x6f6be5c4, "module_put" },
	{ 0x8710888f, "kmem_cache_alloc" },
	{ 0xf55c1c0b, "ieee80211_note" },
	{ 0x4a83bf4d, "ieee80211_scan_add_channels" },
	{ 0x86ed57f7, "ieee80211_create_ibss" },
	{ 0x3bd1b1f6, "msecs_to_jiffies" },
	{ 0x6c572bad, "ieee80211_scan_dump_channels" },
	{ 0x37a0cba, "kfree" },
	{ 0x6067a146, "memcpy" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=wlan";


MODULE_INFO(srcversion, "267F5A3C623BA60445E5BCA");
