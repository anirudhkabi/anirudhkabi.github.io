#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xc0196af1, "struct_module" },
	{ 0xb80330df, "kmalloc_caches" },
	{ 0x8a5d0bb1, "ieee80211_crypto_register" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0x236a0fbe, "ieee80211_note_mac" },
	{ 0xdd132261, "printk" },
	{ 0x8798efc7, "skb_over_panic" },
	{ 0x6f6be5c4, "module_put" },
	{ 0x8710888f, "kmem_cache_alloc" },
	{ 0x6b2dc060, "dump_stack" },
	{ 0x17260c18, "skb_under_panic" },
	{ 0xf1aaffe0, "ieee80211_crypto_unregister" },
	{ 0x37a0cba, "kfree" },
	{ 0x6067a146, "memcpy" },
	{ 0xa3a5be95, "memmove" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=wlan";


MODULE_INFO(srcversion, "6BFDB0DE5960755145702FF");
