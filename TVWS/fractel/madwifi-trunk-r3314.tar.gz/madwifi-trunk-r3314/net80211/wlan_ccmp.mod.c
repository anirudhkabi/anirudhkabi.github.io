#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xc0196af1, "struct_module" },
	{ 0xb80330df, "kmalloc_caches" },
	{ 0x8a5d0bb1, "ieee80211_crypto_register" },
	{ 0xc45b2385, "ieee80211_notify_replay_failure" },
	{ 0x236a0fbe, "ieee80211_note_mac" },
	{ 0xdd132261, "printk" },
	{ 0xac783a7f, "crypto_free_tfm" },
	{ 0x8798efc7, "skb_over_panic" },
	{ 0x6f6be5c4, "module_put" },
	{ 0x8710888f, "kmem_cache_alloc" },
	{ 0xf55c1c0b, "ieee80211_note" },
	{ 0x6b2dc060, "dump_stack" },
	{ 0x17260c18, "skb_under_panic" },
	{ 0xf1aaffe0, "ieee80211_crypto_unregister" },
	{ 0x37a0cba, "kfree" },
	{ 0xa3a5be95, "memmove" },
	{ 0x22cea7af, "crypto_alloc_base" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=wlan";


MODULE_INFO(srcversion, "5A762BC470F77CA6856A252");
