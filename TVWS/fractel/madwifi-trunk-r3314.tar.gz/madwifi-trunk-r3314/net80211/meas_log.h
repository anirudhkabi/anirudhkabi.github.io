#ifndef MEAS_H
#define MEAS_H

//------------------------- Measurement Parameters --------------------------//

#define NUM_MEAS_LOG 2000

#define COOK_FRAGMENT_NUMBER(x) ((x) & 0x000F)
#define COOK_SEQUENCE_NUMBER(x) (((x) & 0xFFF0) >> 4)

#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MACSTR "%02x:%02x:%02x:%02x:%02x:%02x"

//#define BIT(x) (1 << (x))
#define WLAN_FC_GET_TYPE(fc) (((fc) & (BIT(3) | BIT(2))) >> 2)
#define WLAN_FC_GET_STYPE(fc) \
	(((fc) & (BIT(7) | BIT(6) | BIT(5) | BIT(4))) >> 4)


struct meas_log {
	u_int32_t time; 			//Time of measurement
	u_int32_t mtime; 			//MAC time
	u8 type; 				//frame type (management, normal etc)
	u8 subtype;				//frame subtype
	u8 error; 				//Is frame in error?
	int16_t silence; 			//silence level measure before reception
	int16_t signal; 			//signal level at which frame was received
	u_int16_t rate; 				//data rate (1,2,5.5,11Mbps)	not yet been able to get
	u_int16_t len; 				// frame length			got but seems wrong
	u_int16_t seq_no; 			// frame sequence number
	u16 frame_control;			//frame type/subtype etc
	u_int8_t addr1[6];			//
	u_int8_t addr2[6];
	u_int8_t addr3[6];
	u_int8_t addr4[6];
	//Ashutosh-Nirav Change
	int64_t timestamp_offset;
	
};
typedef struct meas_log meas_log_t;


//--------------------------- Utilities ---------------------------//

// Circular logic
#define succ(x,limit) ((x < (limit-1)) ? (x+1) : 0)
#define pred(x,limit) ((x > 0) ? (x-1) : (limit-1))

#endif
