#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xc0196af1, "struct_module" },
	{ 0x3e347fb6, "register_netdevice" },
	{ 0xb80330df, "kmalloc_caches" },
	{ 0x5a34a45c, "__kmalloc" },
	{ 0x83e84bbe, "__mod_timer" },
	{ 0x4b2f14b4, "jiffies_to_timespec" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x2a823e85, "unregister_netdevice" },
	{ 0x349cba85, "strchr" },
	{ 0x2daa90e5, "register_sysctl_table" },
	{ 0x98b1f5e8, "del_timer" },
	{ 0x25ec1b28, "strlen" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0xcda31108, "proc_dointvec" },
	{ 0xc7a4fbed, "rtnl_lock" },
	{ 0xc56d0f80, "skb_clone" },
	{ 0x20000329, "simple_strtoul" },
	{ 0x736918c3, "skb_copy" },
	{ 0xf89843f9, "schedule_work" },
	{ 0x63ecad53, "register_netdevice_notifier" },
	{ 0x35f4146d, "remove_proc_entry" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x2fd1d81c, "vfree" },
	{ 0xeaa456ed, "_spin_lock_irqsave" },
	{ 0x1d26aa98, "sprintf" },
	{ 0xd8fd8b1c, "sysfs_remove_group" },
	{ 0x7d11c268, "jiffies" },
	{ 0xfe769456, "unregister_netdevice_notifier" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xde0bdcff, "memset" },
	{ 0x9327f992, "proc_mkdir" },
	{ 0x37befc70, "jiffies_to_msecs" },
	{ 0xc16fe12d, "__memcpy" },
	{ 0xdd132261, "printk" },
	{ 0x4bcd07d9, "sysfs_create_group" },
	{ 0x1075bf0, "panic" },
	{ 0x182ffc6e, "free_netdev" },
	{ 0xfaef0ed, "__tasklet_schedule" },
	{ 0xbe499d81, "copy_to_user" },
	{ 0x7ec9bfbc, "strncpy" },
	{ 0x74ab784a, "netif_receive_skb" },
	{ 0xd4abf4dc, "wireless_send_event" },
	{ 0x85abc85f, "strncmp" },
	{ 0xdc3b77f8, "dev_close" },
	{ 0x27147e64, "_spin_unlock_irqrestore" },
	{ 0x9545af6d, "tasklet_init" },
	{ 0xa1c9f3d, "mod_timer" },
	{ 0x9c39233b, "init_net" },
	{ 0x22ba502, "dev_kfree_skb_any" },
	{ 0x647215da, "proc_dostring" },
	{ 0xd72b9bd9, "dev_open" },
	{ 0x82072614, "tasklet_kill" },
	{ 0x8798efc7, "skb_over_panic" },
	{ 0x6f6be5c4, "module_put" },
	{ 0x7dceceac, "capable" },
	{ 0x64a2822, "skb_copy_expand" },
	{ 0x8710888f, "kmem_cache_alloc" },
	{ 0xf4d35ea3, "__alloc_skb" },
	{ 0x93fca811, "__get_free_pages" },
	{ 0x63e71329, "unregister_sysctl_table" },
	{ 0x3bd1b1f6, "msecs_to_jiffies" },
	{ 0x1000e51, "schedule" },
	{ 0x6b2dc060, "dump_stack" },
	{ 0x17260c18, "skb_under_panic" },
	{ 0xccf54602, "create_proc_entry" },
	{ 0xf1384735, "pskb_expand_head" },
	{ 0x2ad47c12, "init_timer" },
	{ 0xe57f111, "vsnprintf" },
	{ 0x72270e35, "do_gettimeofday" },
	{ 0x37a0cba, "kfree" },
	{ 0x6067a146, "memcpy" },
	{ 0x98adfde2, "request_module" },
	{ 0x4966516d, "dev_alloc_name" },
	{ 0xaf25400d, "snprintf" },
	{ 0xa3a5be95, "memmove" },
	{ 0x1bfcde6f, "dev_queue_xmit" },
	{ 0x945bc6a7, "copy_from_user" },
	{ 0x6e720ff2, "rtnl_unlock" },
	{ 0xe914e41e, "strcpy" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "7A8B24A15F824E91A9B9DE6");
